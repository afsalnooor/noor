
from django.conf.urls import url
from django.contrib import admin
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$',views.index),
    url(r'^about/$',views.about),
    url(r'^services/$',views.services),
    url(r'^portfolio$',views.portfolio),
    url(r'^contact$',views.contact),
    url(r'^blog$',views.blog),
]

urlpatterns+=staticfiles_urlpatterns()
