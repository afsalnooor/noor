$(document).ready(function () {
        $(".toggleBtn").click(function () {
            $("header").css("animation-delay", ".01s");
            $("header").slideToggle();

        });

    });
    $(window).on('resize',function () {

        var win=$(this);
        if (win.width()>=576){

            $("header").show();
        }else{
            $("header").hide();
        }

    });